﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlackjackLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackjackLibrary.Tests
{
    [TestClass()]
    public class BlackJackHandTests
    {
        [TestMethod()]
        public void BlackJackHandTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void AddCardTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void DrawTest()
        {
            Assert.Fail();
        }
    }
}