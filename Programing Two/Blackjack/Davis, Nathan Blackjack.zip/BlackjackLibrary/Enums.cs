﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blackjack
{
    public enum CardSuit
    {
        Spades = 1,
        Hearts,
        Clubs,
        Diamonds
    }

    public enum CardFace
    {
        A = 1,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        J,
        Q,
        K
    }
}
